"""The ProofManifest (`zk60.manifest/1`): the signed list of an item's classifier proofs, appended to
the item whenever it is served (D37 addendum; content-credentials / C2PA-style).

One entry per registered category: classifier and model id, policy id and digest, threshold, the
label (yes / no, or "unproved" when no accepted proof exists: fail closed), the statement hash, the
bundle reference (the publication manifest's hash and URI), the anchor reference (chain, contract,
leaf hash; resolvable to the Merkle path once its batch closes) and the item's salted content
commitment. The app's publisher key signs the canonical manifest with Ed25519.

THE KEY IS A LOCAL DEVELOPMENT KEY: generated into a 0600 file under the private data root
(config.SIGNING_KEY); its public half is published in every manifest and at /api/publisher-key.
No real keys.

    build_manifest(...) -> dict (signed)        verify_manifest(manifest, publisher) -> {accepted, reasons, checks}
"""
from __future__ import annotations

import base64
import hashlib
import os

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

from . import config, records

SCHEMA = "zk60.manifest/1"
ISSUER = "Proven Media (local demo publisher, DEV KEY)"


# ---------------------------------------------------------------- the dev key

def _load_or_create() -> Ed25519PrivateKey:
    p = config.SIGNING_KEY
    if not p.exists():
        p.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        raw = Ed25519PrivateKey.generate().private_bytes(serialization.Encoding.Raw, serialization.PrivateFormat.Raw,
                                                         serialization.NoEncryption())
        try:
            fd = os.open(p, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(fd, "wb") as f:
                f.write(raw)
        except FileExistsError:
            pass
    return Ed25519PrivateKey.from_private_bytes(p.read_bytes())


def public_key_hex() -> str:
    return _load_or_create().public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw).hex()


def key_id(pub_hex: str) -> str:
    return hashlib.sha256(bytes.fromhex(pub_hex)).hexdigest()[:16]


def _body(m: dict) -> bytes:
    return records.canonical({k: v for k, v in m.items() if k != "signature"})


def sign(m: dict) -> dict:
    sk = _load_or_create()
    pub = public_key_hex()
    m = dict(m)
    m["issuer"] = {"name": ISSUER, "key_id": key_id(pub), "public_key": pub, "alg": "Ed25519",
                   "note": "local development key; no real keys"}
    m["signature"] = {"alg": "Ed25519", "key_id": key_id(pub),
                      "value": base64.b64encode(sk.sign(_body(m))).decode()}
    return m


# ---------------------------------------------------------------- build

def build_manifest(post: dict, item: dict, anchors: dict, pubs: dict, content_commitment: str | None,
                   failure: str | None = None) -> dict:
    """the signed manifest once the item's labels are complete (D41: every chunk's proofs done or failed).
    `item`: {labels (aggregated per category), chunks: [{index, start, end, record, error}], content_length,
    proved_at}; `anchors` / `pubs`: "c<chunk>.<category>" -> AnchorRef / PublicationRecord of each
    published proof. One entry per (chunk, category): exactly what was published."""
    th = records.threshold()
    entries = []
    prover = {}
    for ch in item.get("chunks", []):
        rec = ch.get("record") or {}
        prover = prover or rec.get("prover", {})
        eff = records.effective_labels(rec if rec else None)
        for c in config.registered_categories():
            if ch.get('category', c['id']) != c['id']:
                continue
            key = f"c{ch['index']}.{c['id']}"
            a, pb = anchors.get(key), pubs.get(key)
            accepted = eff[c["id"]] != records.UNPROVED
            pr = rec.get("prover", {})
            entries.append({
                "chunk": ch["index"], "token_range": [ch["start"], ch["end"]],
                **({'category_chunk_index': ch['category_chunk_index']} if 'category' in ch else {}),
                "category": c["id"], "category_name": c["name"],
                "classifier": f"{config.CLASSIFIER_NAME} (demo stub: {pr.get('model', 'no proof')})" if pr.get("kind") == "stub-next-token"
                              else config.CLASSIFIER_NAME,
                "model_id": pb.model_id if pb else pr.get("model_digest"),
                "profile_id": pb.profile_id if pb else pr.get("token_profile_digest"),
                "verifier_id": config.STUB_BIN_SHA256 if pr.get("kind") == "stub-next-token" else pr.get("binary_sha256"),
                "policy_id": c["policy_id"], "policy_sha256": c["sha256"],
                "threshold": {"tau": th["tau"], "c": th["c"]},
                "verdict": eff[c["id"]],
                "proof_status": "accepted" if accepted else "none",
                "error": None if accepted else (ch.get("error") or "no accepted proof"),
                "verdict_bound_by_proof": bool((rec.get("labels") or {}).get(c["id"], {}).get("bound_by_proof")) if accepted else False,
                "statement_sha256": (pb.statement_sha256 if pb else rec.get("statement_sha256")) if accepted else None,
                "bundle": {"manifest_sha256": a.manifest_sha256, "manifest_uri": a.manifest_uri,
                           "receipt_uris": len(a.receipt_uris)} if (a and accepted) else None,
                "anchor": {"chain": a.chain, "contract": a.contract, "leaf_hash": a.leaf_hash,
                           "resolve": f"post {post['id']} chunk {ch['index']} category {c['id']}"} if (a and accepted) else None,
                "content_commitment": content_commitment,
            })
    labels = {c: {"value": v["value"], "proof": v["proof"]} for c, v in (item.get("labels") or {}).items()}
    m = {"schema": SCHEMA, "item": {"post_id": post["id"], "kind": post["kind"], "created_at": post["created_at"],
                                    "content_commitment": content_commitment,
                                    "content_commitment_rule": "SHA-256(\"zk60/proven-media/content/v1\" || salt_32 || u64-be len || UTF-8 content)",
                                    "content_length_tokens": item.get("content_length")},
         "category_set": {"id": config.category_set_id(), "digest": records.category_set_digest()},
         "chunking": item.get("chunking"),
         "labels": labels,
         "label_rule": "per category: yes if any chunk is proved yes; not proved if any chunk lacks an accepted proof (fail closed); else no",
         "proved_once_at_creation": item.get("proved_at"),
         "entries": entries, "issued_at": records.now_iso(),
         "notes": (["DEMO STUB: one next-token proof per chunk stands in for that chunk's three category proofs; labels come "
                    "from a placeholder and are not bound by the proof."] if prover.get("kind") == "stub-next-token" else [])
                  + (["Privacy statement pending; moderate policies selected for this testnet demo."]
                     if prover.get("kind") == "shieldstral" else [])
                  + (["Public content only; privacy not claimed. W16R2 development candidate; not production."]
                     if prover.get("kind") == "shieldstral-fast-w16r2" else [])
                  + ([f"{failure}"] if failure else [])}
    return sign(m)


# ---------------------------------------------------------------- verify

def verify_signature(m: dict, expected_public_key: str | None = None) -> dict:
    """Check the publisher signature over the canonical manifest without accessing a store."""
    checks = {"schema": isinstance(m, dict) and m.get("schema") == SCHEMA}
    issuer = m.get("issuer") if isinstance(m, dict) else None
    signature = m.get("signature") if isinstance(m, dict) else None
    public = issuer.get("public_key") if isinstance(issuer, dict) else None
    if expected_public_key is not None:
        checks["issuer_key"] = (isinstance(public, str) and isinstance(expected_public_key, str)
                               and len(expected_public_key) == 64 and public.lower() == expected_public_key.lower())
    checks["signature"] = False
    if isinstance(public, str) and isinstance(signature, dict):
        try:
            key = Ed25519PublicKey.from_public_bytes(bytes.fromhex(public))
            key.verify(base64.b64decode(signature["value"], validate=True), _body(m))
            checks["signature"] = (signature.get("alg") == issuer.get("alg") == "Ed25519"
                                   and signature.get("key_id") == issuer.get("key_id") == key_id(public))
        except (InvalidSignature, KeyError, TypeError, ValueError):
            pass
    failures = {"schema": "unsupported manifest schema", "issuer_key": "publisher key differs from the supplied key",
                "signature": "the Ed25519 signature does not verify for this manifest and key"}
    reasons = [f"{name}: {failures[name]}" for name, ok in checks.items() if not ok]
    return {"accepted": not reasons, "checks": checks, "reasons": reasons}


def verify_manifest(m: dict, publisher, expected_public_key: str | None = None, rehash_segments: bool = False) -> dict:
    """Check the signature, then compare the entries and their anchors with the public ledger."""
    signed = verify_signature(m, expected_public_key)
    if not signed["accepted"]:
        return {**signed, "pending_anchor": []}
    reasons, checks = signed["reasons"], signed["checks"]

    def chk(name, ok, why=""):
        checks[name] = bool(ok)
        if not ok:
            reasons.append(f"{name}: {why}" if why else name)

    from . import w16r2_runtime
    from .provers import ProverError
    entries = m.get('entries', [])
    if not isinstance(entries, list) or not all(isinstance(e, dict) for e in entries):
        return {**signed, 'accepted':False, 'reasons':['malformed manifest entries'], 'pending_anchor':[]}
    declared_set = m.get('category_set')
    w16r2 = ((isinstance(declared_set, dict) and declared_set.get('id') == config.W16R2_CATEGORY_SET_ID)
             or any(e.get('profile_id') == w16r2_runtime.PROFILE_SHA for e in entries))
    coverage = None
    if w16r2:
        from .w16r2_public_verifier import signed_post_coverage
        try:
            coverage = signed_post_coverage(m)
        except (OSError, ValueError, ProverError) as exc:
            chk('w16r2_signed_post_coverage', False, str(exc))
            return {'accepted':False, 'checks':checks, 'reasons':reasons, 'pending_anchor':[]}
        if coverage is not None:
            chk('w16r2_signed_post_coverage', True)
    pid = m.get("item", {}).get("post_id")
    pending = []
    for e in entries:
        c = e.get("category")
        tag = f"c{e.get('chunk', 0)}.{c}"
        if e.get("verdict") == records.UNPROVED:
            chk(f"{tag}.unproved_has_no_anchor", e.get("anchor") is None, "an unproved entry names an anchor")
            continue
        a = publisher.anchor_of(pid, c, e.get("chunk", 0))
        if a is None:
            chk(f"{tag}.anchor", False, "no anchor for this entry in the ledger")
            continue
        if coverage is not None:
            bundle = e.get('bundle')
            chk(f'{tag}.signed_bundle', isinstance(bundle, dict) and bundle.get('manifest_sha256') == a.manifest_sha256
                and bundle.get('manifest_uri') == a.manifest_uri
                and type(bundle.get('receipt_uris')) is int and bundle['receipt_uris'] == len(a.receipt_uris),
                'signed receipt inventory differs from the publication anchor')
        chk(f"{tag}.anchor_leaf", a.leaf_hash == (e.get("anchor") or {}).get("leaf_hash"), "the leaf differs from the ledger's")
        r = publisher.verify_publication(a, rehash_segments=rehash_segments)
        man = r.get("manifest") or {}
        same = (man.get("verdict") == e.get("verdict") and man.get("statement_sha256") == e.get("statement_sha256")
                and man.get("policy_id") == e.get("policy_sha256") and man.get("model_id") == e.get("model_id")
                and man.get("profile_id") == e.get("profile_id")
                and (man.get("verifier_id") == e.get("verifier_id")
                     or (man.get("verifier_id") == "00" * 32 and e.get("verifier_id") is None))
                and man.get("content_commitment") == e.get("content_commitment")
                and list(man.get("token_range", [])) == list(e.get("token_range", [])))
        chk(f"{tag}.publication_matches", same, "the published label, statement, policy, model, profile, verifier or commitment differs")
        if r.get("pending"):
            pending.append(tag)
            checks[f"{tag}.anchored"] = False
        else:
            chk(f"{tag}.anchored", r.get("accepted"), "; ".join(r.get("reasons", [])))
    result = {"accepted": not reasons, "pending_anchor": pending, "reasons": reasons, "checks": checks}
    if coverage is not None:
        result['signed_post_coverage'] = coverage
    return result
